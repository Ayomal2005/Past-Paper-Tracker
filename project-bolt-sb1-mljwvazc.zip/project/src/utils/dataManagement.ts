import { Paper, ExportData } from '../types/paper';

export const exportData = (papers: Paper[]): void => {
  try {
    const dataToExport: ExportData = {
      papers,
      exportDate: new Date().toISOString(),
      version: '1.0'
    };
    
    const dataStr = JSON.stringify(dataToExport, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `past-papers-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Error exporting data:', error);
    alert('Error exporting data. Please try again.');
  }
};

export const importData = (
  file: File, 
  onSuccess: (papers: Paper[]) => void
): void => {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const result = e.target?.result;
      if (typeof result !== 'string') return;
      
      const importedData = JSON.parse(result);
      
      if (importedData.papers && Array.isArray(importedData.papers)) {
        if (window.confirm('This will replace all current data. Are you sure?')) {
          onSuccess(importedData.papers);
          alert('Data imported successfully!');
        }
      } else {
        alert('Invalid file format. Please select a valid backup file.');
      }
    } catch (error) {
      console.error('Error importing data:', error);
      alert('Error reading file. Please check the file format.');
    }
  };
  reader.readAsText(file);
};