import { Paper } from '../types/paper';
import { STORAGE_KEYS } from '../constants/subjects';

export const loadDataFromStorage = (): { papers: Paper[] | null; lastSaved: Date | null } => {
  try {
    const savedPapers = localStorage.getItem(STORAGE_KEYS.papers);
    const savedLastSaved = localStorage.getItem(STORAGE_KEYS.lastSaved);

    const papers = savedPapers ? JSON.parse(savedPapers) : null;
    const lastSaved = savedLastSaved ? new Date(savedLastSaved) : null;

    if (papers) {
      console.log('Loaded papers from storage:', papers.length, 'papers');
    }

    return { papers, lastSaved };
  } catch (error) {
    console.error('Error loading data from storage:', error);
    return { papers: null, lastSaved: null };
  }
};

export const saveDataToStorage = (papers: Paper[]): Date => {
  try {
    localStorage.setItem(STORAGE_KEYS.papers, JSON.stringify(papers));
    const now = new Date();
    localStorage.setItem(STORAGE_KEYS.lastSaved, now.toISOString());
    console.log('Data saved to storage');
    return now;
  } catch (error) {
    console.error('Error saving data to storage:', error);
    throw error;
  }
};

export const clearStorage = (): void => {
  localStorage.removeItem(STORAGE_KEYS.papers);
  localStorage.removeItem(STORAGE_KEYS.lastSaved);
};