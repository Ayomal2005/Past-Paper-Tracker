export interface Paper {
  id: string;
  subject: string;
  year: number;
  type: string;
  status: 'not-started' | 'in-progress' | 'completed';
  score: number | null;
  timeSpent: number; // in seconds
  completedAt: string | null;
  notes: string;
  difficulty: 'easy' | 'medium' | 'hard' | null;
  startTime: string | null;
}

export interface Stats {
  total: number;
  completed: number;
  inProgress: number;
  avgScore: number;
  totalTime: number;
}

export interface SubjectStats {
  completed: number;
  total: number;
  avgScore: number;
  percentage: number;
}

export interface ExportData {
  papers: Paper[];
  exportDate: string;
  version: string;
}