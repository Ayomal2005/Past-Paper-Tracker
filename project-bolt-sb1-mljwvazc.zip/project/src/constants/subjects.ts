export const SUBJECTS = ['Mathematics', 'Chemistry', 'Physics'] as const;

export const YEARS = Array.from({ length: 10 }, (_, i) => 2024 - i);

export const STORAGE_KEYS = {
  papers: 'pastPapers_data',
  lastSaved: 'pastPapers_lastSaved'
} as const;

export const getPaperTypes = (subject: string): string[] => {
  if (subject === 'Mathematics') {
    return ['Paper I', 'Paper II'];
  } else {
    return ['MCQ Paper', 'Paper II'];
  }
};