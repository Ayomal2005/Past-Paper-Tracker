import React from 'react';
import PastPaperTracker from './components/PastPaperTracker';

function App() {
  return <PastPaperTracker />;
}

export default App;