import React from 'react';
import { BookOpen, CheckCircle2, Clock, Award, Timer } from 'lucide-react';
import { Stats } from '../types/paper';
import { formatTime } from '../utils/time';

interface StatsOverviewProps {
  stats: Stats;
}

export const StatsOverview: React.FC<StatsOverviewProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-6 mb-6 sm:mb-8">
      <div className="bg-white rounded-xl p-4 sm:p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs sm:text-sm text-gray-600">Total Papers</p>
            <p className="text-xl sm:text-3xl font-bold text-gray-800">{stats.total}</p>
          </div>
          <BookOpen className="w-6 h-6 sm:w-8 sm:h-8 text-blue-500" />
        </div>
      </div>
      
      <div className="bg-white rounded-xl p-4 sm:p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs sm:text-sm text-gray-600">Completed</p>
            <p className="text-xl sm:text-3xl font-bold text-green-600">{stats.completed}</p>
          </div>
          <CheckCircle2 className="w-6 h-6 sm:w-8 sm:h-8 text-green-500" />
        </div>
      </div>
      
      <div className="bg-white rounded-xl p-4 sm:p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs sm:text-sm text-gray-600">In Progress</p>
            <p className="text-xl sm:text-3xl font-bold text-yellow-600">{stats.inProgress}</p>
          </div>
          <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-500" />
        </div>
      </div>
      
      <div className="bg-white rounded-xl p-4 sm:p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs sm:text-sm text-gray-600">Avg Score</p>
            <p className="text-xl sm:text-3xl font-bold text-purple-600">{stats.avgScore}%</p>
          </div>
          <Award className="w-6 h-6 sm:w-8 sm:h-8 text-purple-500" />
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 sm:p-6 shadow-lg col-span-2 lg:col-span-1">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs sm:text-sm text-gray-600">Total Time</p>
            <p className="text-lg sm:text-2xl font-bold text-indigo-600">{formatTime(stats.totalTime)}</p>
          </div>
          <Timer className="w-6 h-6 sm:w-8 sm:h-8 text-indigo-500" />
        </div>
      </div>
    </div>
  );
};