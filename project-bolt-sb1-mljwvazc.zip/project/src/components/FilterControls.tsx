import React from 'react';
import { SUBJECTS, YEARS } from '../constants/subjects';

interface FilterControlsProps {
  selectedSubject: string;
  selectedYear: string;
  selectedStatus: string;
  onSubjectChange: (subject: string) => void;
  onYearChange: (year: string) => void;
  onStatusChange: (status: string) => void;
}

export const FilterControls: React.FC<FilterControlsProps> = ({
  selectedSubject,
  selectedYear,
  selectedStatus,
  onSubjectChange,
  onYearChange,
  onStatusChange
}) => {
  return (
    <div className="bg-white rounded-xl p-4 sm:p-6 shadow-lg mb-6 sm:mb-8">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Filters</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <select 
          className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          value={selectedSubject}
          onChange={(e) => onSubjectChange(e.target.value)}
        >
          <option value="all">All Subjects</option>
          {SUBJECTS.map(subject => (
            <option key={subject} value={subject}>{subject}</option>
          ))}
        </select>
        
        <select 
          className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          value={selectedYear}
          onChange={(e) => onYearChange(e.target.value)}
        >
          <option value="all">All Years</option>
          {YEARS.map(year => (
            <option key={year} value={year}>{year}</option>
          ))}
        </select>
        
        <select 
          className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          value={selectedStatus}
          onChange={(e) => onStatusChange(e.target.value)}
        >
          <option value="all">All Status</option>
          <option value="not-started">Not Started</option>
          <option value="in-progress">In Progress</option>
          <option value="completed">Completed</option>
        </select>
      </div>
    </div>
  );
};