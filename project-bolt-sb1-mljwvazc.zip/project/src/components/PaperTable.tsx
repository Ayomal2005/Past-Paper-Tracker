import React from 'react';
import { CheckCircle2, Circle, Clock } from 'lucide-react';
import { Paper } from '../types/paper';
import { timeInputToSeconds, secondsToTimeInput, formatTime } from '../utils/time';

interface PaperTableProps {
  papers: Paper[];
  onUpdatePaper: (paperId: string, updates: Partial<Paper>) => void;
}

export const PaperTable: React.FC<PaperTableProps> = ({ papers, onUpdatePaper }) => {
  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-50';
      case 'in-progress': return 'text-yellow-600 bg-yellow-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getDifficultyColor = (difficulty: string | null): string => {
    switch (difficulty) {
      case 'easy': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'hard': return 'text-red-600';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-4 sm:p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-800">
          Past Papers ({papers.length} papers)
        </h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full min-w-[800px]">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 sm:px-6 py-4 text-left text-sm font-semibold text-gray-600">Paper</th>
              <th className="px-4 sm:px-6 py-4 text-left text-sm font-semibold text-gray-600">Status</th>
              <th className="px-4 sm:px-6 py-4 text-left text-sm font-semibold text-gray-600">Score</th>
              <th className="px-4 sm:px-6 py-4 text-left text-sm font-semibold text-gray-600">Time</th>
              <th className="px-4 sm:px-6 py-4 text-left text-sm font-semibold text-gray-600">Difficulty</th>
              <th className="px-4 sm:px-6 py-4 text-left text-sm font-semibold text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {papers.map(paper => (
              <tr key={paper.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-4 sm:px-6 py-4">
                  <div>
                    <div className="font-medium text-gray-800 text-sm sm:text-base">
                      {paper.subject} - {paper.type}
                    </div>
                    <div className="text-xs sm:text-sm text-gray-600">{paper.year}</div>
                  </div>
                </td>
                
                <td className="px-4 sm:px-6 py-4">
                  <span className={`inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm font-medium ${getStatusColor(paper.status)}`}>
                    {paper.status === 'completed' && <CheckCircle2 className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />}
                    {paper.status === 'in-progress' && <Clock className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />}
                    {paper.status === 'not-started' && <Circle className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />}
                    <span className="hidden sm:inline">
                      {paper.status.replace('-', ' ').toUpperCase()}
                    </span>
                    <span className="sm:hidden">
                      {paper.status === 'not-started' ? 'NEW' : 
                       paper.status === 'in-progress' ? 'PROG' : 'DONE'}
                    </span>
                  </span>
                </td>
                
                <td className="px-4 sm:px-6 py-4">
                  {paper.score !== null ? (
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{paper.score}%</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        className="w-12 sm:w-16 p-1 text-xs sm:text-sm border border-gray-300 rounded"
                        value={paper.score}
                        onChange={(e) => onUpdatePaper(paper.id, { score: parseInt(e.target.value) || 0 })}
                      />
                    </div>
                  ) : (
                    <input
                      type="number"
                      min="0"
                      max="100"
                      placeholder="Score"
                      className="w-16 sm:w-20 p-1 sm:p-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                      onChange={(e) => onUpdatePaper(paper.id, { score: parseInt(e.target.value) || null })}
                    />
                  )}
                </td>

                <td className="px-4 sm:px-6 py-4">
                  <div className="flex items-center gap-2">
                    <input
                      type="time"
                      className="w-16 sm:w-20 p-1 sm:p-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                      value={secondsToTimeInput(paper.timeSpent)}
                      onChange={(e) => onUpdatePaper(paper.id, { timeSpent: timeInputToSeconds(e.target.value) })}
                    />
                    <span className="text-xs text-gray-500 hidden sm:inline">
                      {formatTime(paper.timeSpent)}
                    </span>
                  </div>
                </td>
                
                <td className="px-4 sm:px-6 py-4">
                  <select 
                    className={`text-xs sm:text-sm border border-gray-300 rounded p-1 ${getDifficultyColor(paper.difficulty)}`}
                    value={paper.difficulty || ''}
                    onChange={(e) => onUpdatePaper(paper.id, { difficulty: e.target.value as any || null })}
                  >
                    <option value="">Rate</option>
                    <option value="easy">Easy</option>
                    <option value="medium">Medium</option>
                    <option value="hard">Hard</option>
                  </select>
                </td>
                
                <td className="px-4 sm:px-6 py-4">
                  <div className="flex flex-col sm:flex-row gap-1 sm:gap-2">
                    {paper.status === 'not-started' && (
                      <button
                        onClick={() => onUpdatePaper(paper.id, { status: 'in-progress' })}
                        className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-md font-medium transition-colors"
                      >
                        Start
                      </button>
                    )}
                    
                    {paper.status === 'in-progress' && (
                      <button
                        onClick={() => onUpdatePaper(paper.id, { status: 'completed' })}
                        className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-green-100 text-green-700 hover:bg-green-200 rounded-md font-medium transition-colors"
                      >
                        Complete
                      </button>
                    )}
                    
                    {paper.status === 'completed' && (
                      <button
                        onClick={() => onUpdatePaper(paper.id, { 
                          status: 'not-started',
                          score: null,
                          timeSpent: 0,
                          difficulty: null,
                          startTime: null
                        })}
                        className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-gray-100 text-gray-700 hover:bg-gray-200 rounded-md font-medium transition-colors"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};