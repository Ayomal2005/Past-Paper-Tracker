import React from 'react';
import { Target } from 'lucide-react';
import { Paper, SubjectStats } from '../types/paper';
import { SUBJECTS } from '../constants/subjects';

interface SubjectProgressProps {
  papers: Paper[];
}

export const SubjectProgress: React.FC<SubjectProgressProps> = ({ papers }) => {
  const getSubjectStats = (subject: string): SubjectStats => {
    const subjectPapers = papers.filter(p => p.subject === subject);
    const completed = subjectPapers.filter(p => p.status === 'completed').length;
    const total = subjectPapers.length;
    const avgScore = subjectPapers.filter(p => p.score !== null).reduce((acc, p, _, arr) => acc + p.score! / arr.length, 0);
    
    return { 
      completed, 
      total, 
      avgScore: Math.round(avgScore) || 0, 
      percentage: Math.round((completed / total) * 100) 
    };
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
      {SUBJECTS.map(subject => {
        const subjectStats = getSubjectStats(subject);
        return (
          <div key={subject} className="bg-white rounded-xl p-4 sm:p-6 shadow-lg">
            <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <Target className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500" />
              {subject}
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span className="font-semibold">{subjectStats.completed}/{subjectStats.total}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${subjectStats.percentage}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>{subjectStats.percentage}% Complete</span>
                <span>Avg: {subjectStats.avgScore}%</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};